import urllib2
import sys

# ISSUES
# in LLE the last request seems to throw 500 error
file_name = raw_input('Input file name: ')
endpoint = raw_input('Enter endpoint url: ')

def close_program():
    print '\n...exiting\n'
    raw_input("press \'ENTER\' to exit the program\n")
    sys.exit(1)

def apps_to_list(file_name):
    appList = []
    try:
        with open(file_name, 'r') as filehandle:
            for item in filehandle:
                app = item[:-1]
                appList.append(app)
        if len(appList) == 0:
            print '\nthere are 0 applications in this file'
            close_program()
        return appList

    except IOError as i:
        print "\n"
        print i
        close_program()

def make_post_request(appList, endpoint):   
    clen = len(appList)
    headers = {
        "Accept" : "application/json",
        "Content-Type" : "application/json",
    }
    for i in range(0, clen):
        print '\nsubmitting...\n'
        try:
            req = urllib2.Request(endpoint, appList[i], headers)
            f = urllib2.urlopen(req)
            print appList[i] + "\n"
            print f.read()
            f.close()
        except Exception as e:
            print e
            close_program()
    print '\n\n-----------------you have successfully submitted applications------------------------'
    close_program()

make_post_request(apps_to_list(file_name), endpoint)

